package com.bobsCrypto;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.bobsCrypto.bean.Response;

import junit.framework.Assert;

class MainApplicationTest {

	MainApplication application;

	@BeforeEach
	public void setup() {
		application = new MainApplication();
	}

	@Test
	void testReadFile() {
		List<Response> response = application.readFile("D://Ganesh/Personal/PersonalWorkspace/BobsCrypto/src/resources/bobs_crypto.txt");
		Assert.assertEquals(3, response.size());
	}
}
