package com.bobsCrypto;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.json.JSONObject;
import org.json.JSONException;

import com.bobsCrypto.bean.CryptoValue;
import com.bobsCrypto.bean.Response;

public class MainApplication {


	private static final String URL = "https://min-api.cryptocompare.com/data/price?fsym=%s&tsyms=%s";
	private static final String CURRENCY = "EUR";

	public static void main(String... args) {
		try {
			MainApplication mainApplication = new MainApplication();
			List<Response> responselist = mainApplication.readFile(args[0]);
			CryptoValue finalrResponse = updateResponse(responselist, mainApplication);
			System.out.println(finalrResponse.toString());
		} catch (JSONException | IOException e) {
			e.printStackTrace();
		}
	}

	public static CryptoValue updateResponse(List<Response> responselist, MainApplication mainApplication) throws JSONException, IOException {
		BigDecimal totalValue = new BigDecimal(0);
		CryptoValue cryptoValue = new CryptoValue();
		for(Response response : responselist) {
			BigDecimal value = mainApplication.getResponse(response.getSymbole(), CURRENCY);
			response.setValue(value.multiply(new BigDecimal(response.getQuantity())));
			totalValue.add(response.getValue());
		}
		cryptoValue.setResponse(responselist);
		cryptoValue.setTotalValue(totalValue);
		return cryptoValue;
	}

	public List<Response> readFile(String filePath) {
		
		List<Response> responseList = new ArrayList<Response>();
		try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
			stream.forEach(line -> {
				Response r = new Response();
				String[] data = line.split("=");
				r.setSymbole(data[0]);
				r.setQuantity(data[1]);
				responseList.add(r);
			});
		} catch (IOException e) {
			e.printStackTrace();
		} 
		return responseList;
	}

	private BigDecimal getResponse(String symbole, String currency) throws JSONException, IOException {
			URL url = new URL(String.format(URL, symbole, currency));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
			String output;
			while ((output = br.readLine()) != null) {
				JSONObject json = new JSONObject(output);
				if(json.keys().hasNext()) {
					String key = json.keys().next().toString();
					return new BigDecimal(json.get(key).toString());
				}		
			}
			conn.disconnect();
		return null;
	}


}
