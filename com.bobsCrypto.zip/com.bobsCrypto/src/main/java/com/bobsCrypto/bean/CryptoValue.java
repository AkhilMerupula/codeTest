package com.bobsCrypto.bean;

import java.math.BigDecimal;
import java.util.List;

public class CryptoValue {
	private List<Response> response;
	private BigDecimal totalValue;
	public List<Response> getResponse() {
		return response;
	}
	public void setResponse(List<Response> response) {
		this.response = response;
	}
	public BigDecimal getTotalValue() {
		return totalValue;
	}
	public void setTotalValue(BigDecimal totalValue) {
		this.totalValue = totalValue;
	}
	@Override
	public String toString() {
		return String.format("%s, totalValue=%s", response.toString(), totalValue);
	}
	
	

}
