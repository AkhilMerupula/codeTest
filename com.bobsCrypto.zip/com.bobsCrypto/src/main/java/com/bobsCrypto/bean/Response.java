package com.bobsCrypto.bean;

import java.math.BigDecimal;

public class Response {
	
	private String symbole;
	private String quantity;
	private BigDecimal value;
	
	

	public String getSymbole() {
		return symbole;
	}

	public void setSymbole(String symbole) {
		this.symbole = symbole;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal bigDecimal) {
		this.value = bigDecimal;
	}
	
	@Override
	public String toString() {
		return String.format("Crypto =%s, Quantity=%s, Value=%s \n", symbole, quantity, value);
	}
}
